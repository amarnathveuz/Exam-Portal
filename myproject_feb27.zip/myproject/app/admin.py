from django.contrib import admin

# Register your models here.

from .models import  *

admin.site.register(Class_master)
admin.site.register(Main_Exam_section)

